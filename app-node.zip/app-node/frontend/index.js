const { json } = require("body-parser");

async function cadastrar(event) {
    event.preventDefault();

    const Nome = document.getElementById('nome').value;
    const Telefone = document.getElementById('telefone').value;
    const Aniversario = document.getElementById('aniversario').value;
    const Email = document.getElementById('email').value;
    const Senha = document.getElementById('senha').value;

    const data = { Nome, Telefone, Aniversario, Email, Senha }

    try {
        const response = await fetch('http://localhost:3000/usuarios/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const results = await response.json();

        if (results.success) {
            alert(results.message);
        } else {
            alert(results.message);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao tentar cadastrar. Tente novamente mais tarde.');
    }
}

async function logar(event) {
    event.preventDefault();

    const email = document.getElementById('email_login').value;
    const senha = document.getElementById('senha_login').value;

    const data = { email, senha }
    console.log(data)

    const response = await fetch("http://localhost:3000/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })

    let results = await response.json();

    if (results.success) {
        let userData = results.data;

        localStorage.setItem('informacoes', JSON.stringify(userData))

        let html = document.getElementById('informacoes')
        let dados = JSON.parse(localStorage.getItem('informacoes'))
        console.log(dados)

        html.innerHTML = `<div style="display: flex flex-direction: column; align=items: center"> 
                            Perfil: ${dados.perfil}
                            </div>`

        html.style.display = 'block'

        alert(results.message)
    } else {
        alert(results.message)
    }
}

