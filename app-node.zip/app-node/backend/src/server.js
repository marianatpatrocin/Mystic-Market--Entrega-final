const express = require('express');
const cors = require('cors')
const app = express();
const port = 3000;

app.use(express.json());
app.use(cors())


app.listen(port, () => console.log(`Rodando na porta ${port}`));

const connection = require('./db_config.js');

app.post('/usuarios/cadastrar', (request, response) => {

    let params = [
            request.body.Nome,
            request.body.Telefone,
            request.body.Aniversario,
            request.body.Email,
            request.body.Senha
        ]
        
        let query = "INSERT INTO usuariosCadastrar(nome, telefone, aniversario, email, senha) VALUES (?, ?, ?, ?, ?);"
        connection.query(query, params, (err, results) => {
            if (err) {
                return response.status(400).json({
                    success: false,
                    message: "Erro ao cadastrar usuário",
                    data: err
                });
            } else {
                return response.status(201).json({
                    success: true,
                    message: "Usuário cadastrado com sucesso",
                    data: results
                });
            }
        });
    });
        
app.get('/usuarios/listar', (request, response) => {
    let query = "SELECT * FROM usuariosCadastrar";
    connection.query(query, (err, results) => {
        if (results) {
            response.status(201).json({
                success: true,
                message: "Sucesso",
                data: results
            });
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    data: err
                });
        }
    });
});

app.put('/usuarios/editar/:id', (request, response) => {
    let params = Array (
        request.body.nome,
        request.body.telefone,
        request.body.aniversario,
        request.body.email,
        request.body.senha,
        request.params.id 
    )

    let query = "UPDATE usuariosCadastrar SET nome = ?, telefone = ?, aniversario = ?, email = ?, senha = ? WHERE id = ?;";
    connection.query(query, params, (err, results) => {
        if (results) {
            response.status(201).json({
                success: true,
                message: "Sucesso",
                data: results
            });
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    data: err
                });
        }
    });
});

app.delete('/usuarios/deletar/:id', (request, response) => {
    let query = "DELETE FROM usuariosCadastrar WHERE id = ?";
    connection.query(query, [request.params.id], (err, results) => {
        if (err) {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Erro ao deletar usuário",
                    error: err
                });
        } else {
            if (results.affectedRows > 0) {
                response.status(200).json({
                    success: true,
                    message: "Usuário deletado",
                    data: results
                });
            } else {
                response.status(404).json({
                    success: false,
                    message: "Usuário não encontrado"
                });
            }
        }
    });
});

app.post('/login', (request, response) => {
    let params = [request.body.email];

    let query = "SELECT id,email,senha,perfil FROM usuariosCadastrar WHERE email = ?";
    connection.query(query, params, (err, results) => {
        if (err) {
            return response.status(500).json({
                success: false,
                message: "Erro no servidor",
            });
        }

        if (results.length > 0) {
            let senhaDigitada = request.body.senha;
            let senhaBanco = results[0].senha;

            if (senhaBanco === senhaDigitada) {
                return response.status(200).json({
                    success: true,
                    message: "Sucesso",
                    data: results[0],
                });
            } else {
                return response.status(400).json({
                    success: false,
                    message: "Senha incorreta!",
                });
            }
        } else {
            return response.status(400).json({
                success: false,
                message: "E-mail não cadastrado!",
            });
        }
    });
});
